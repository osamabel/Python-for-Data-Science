"""ft_package - A sample test package."""

from .count_in_list import count_in_list

__all__ = ['count_in_list']
__version__ = '0.0.1'

